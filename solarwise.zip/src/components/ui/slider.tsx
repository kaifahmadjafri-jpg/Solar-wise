import { Slider as SliderPrimitive } from "@base-ui/react/slider"

import { cn } from "@/lib/utils"

function Slider({
  className,
  defaultValue,
  value,
  min = 0,
  max = 100,
  onValueChange,
  ...props
}: SliderPrimitive.Root.Props) {
  const _values = Array.isArray(value)
    ? value
    : Array.isArray(defaultValue)
      ? defaultValue
      : [min]

  return (
    <SliderPrimitive.Root
      className={cn("relative flex w-full touch-none items-center select-none py-4", className)}
      data-slot="slider"
      defaultValue={defaultValue}
      value={value}
      min={min}
      max={max}
      onValueChange={onValueChange}
      {...props}
    >
      <SliderPrimitive.Control className="relative flex w-full touch-none items-center select-none h-10">
        <SliderPrimitive.Track
          data-slot="slider-track"
          className="relative grow overflow-hidden rounded-full bg-slate-200 h-3 w-full"
        >
          <SliderPrimitive.Indicator
            data-slot="slider-range"
            className="absolute bg-yellow-500 h-full left-0"
          />
        </SliderPrimitive.Track>
        {_values.map((_, index) => (
          <SliderPrimitive.Thumb
            data-slot="slider-thumb"
            key={index}
            className="relative block size-10 shrink-0 rounded-full border-4 border-yellow-500 bg-white shadow-2xl ring-yellow-500/40 transition-all select-none hover:scale-110 focus-visible:ring-4 focus-visible:ring-yellow-500/50 focus-visible:outline-none active:scale-95 disabled:pointer-events-none disabled:opacity-50 cursor-grab active:cursor-grabbing z-30"
          />
        ))}
      </SliderPrimitive.Control>
    </SliderPrimitive.Root>
  )
}

export { Slider }
